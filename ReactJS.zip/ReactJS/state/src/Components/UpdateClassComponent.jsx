import React from "react";
class Person extends React.Component{
    constructor(props){
        super(props);
        this.state={
            name:"Aishwarya Somaiya",
            contactno:"8288393883",
            salary:90000
        };
    }

    updateSalary=() => {
        this.setState({salary:30000});
    }
// The state is an instance of React Component Class can be defined as an object of a set of observable properties that control the behavior of the component. In other words, the State of a component is an object that holds some information that may change over the lifetime of the component.
// The setState() method to change the state object, it will ensure that the component knows its been updated and calls the render() method (and all the other lifecycle methods).
    render(){
        return(
            <div>
                <h1>My name is:{this.state.name}</h1>
                <p>
                    My conatct no is:{this.state.contactno}
                </p>
                <p>
                    My monthly salalry is:{this.state.salary}
                </p>
                <button type="button" onClick={this.updateSalary}>Update Salary</button>
            </div>
        );
    }
}

export default Person;