import './App.css';
import ClassComponent from './component/classcomponent';
import FunctionComponent from './component/functioncomponent';
import {BrowserRouter,Route,Routes} from "react-router-dom";


function App() {
  return (
    //Note:with using Components{BrowserRouter,Route,Routes}
      <BrowserRouter>
        <Routes>
          <Route path="/ClassComponent" element={<FunctionComponent/>}>  </Route>
          <Route path="/ClassComponent" element={<ClassComponent/>}>  </Route>
        </Routes>
      </BrowserRouter>

      
        //Note:without using Components , using class/function only
        //<div>
        // <h1>APP component</h1>
        // <FunctionComponent/>
        // <ClassComponent/> 
        //</div>
  );
    
}

export default App;
