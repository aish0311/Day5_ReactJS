import React from 'react'
class ClassComponent extends React.Component{
    render(){
        return <h1>Custom function</h1>
        };
    
}

export default ClassComponent;