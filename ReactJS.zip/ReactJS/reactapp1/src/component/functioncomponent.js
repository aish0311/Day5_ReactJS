
function FunctionComponent(){ 

    return(
        <h2> Custom function</h2>
    );
    

}

export default FunctionComponent;